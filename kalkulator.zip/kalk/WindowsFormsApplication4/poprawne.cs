﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApplication4

{
    public partial class Form1 : Form
    {
      
        string input = string.Empty;
        double result = 0.0;
        double tmp = 0.0;
        double umowa = 0.0;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {

            if (radioButton3.Checked)
            {
                //ubezpieczenie emerytalne - 9.76% ; ubezpieczenie rentowe -1.5% ; ubezpieczenie chorobowe - 2.45 % ; 
                //ubezpieczenie zdrowotne - 7.77 % ; zaliczka na PIT -2.2 %
                 umowa =0.7632;
            }
            else if (radioButton4.Checked)
            {
                if (radioButton1.Checked)
                {
                    //14.4% zaliczka na PIT
                    umowa = 0.856;
                }
                else if (radioButton2.Checked)
                {
                    //6.7% zaliczka na PIT; 9% ubezpieczenie zdrowotne;
                    umowa=0.843;
                };

            }
            else if (radioButton5.Checked)
            {
                //14.4% zaliczka na PIT
                umowa=0.856;
            };   

            double result = double.Parse(textBox1.Text) * umowa;                                 
            textBox2.Text = result.ToString();
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            // allows only numbers
            if (!char.IsNumber(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }
    }
}
